from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.core.config import settings
from src.database import init_db
from src.api.v1 import platos, vinos

app = FastAPI(title=settings.app_name, version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    if settings.env == "dev":
        init_db()

app.include_router(platos.router, prefix="/api/v1")
app.include_router(vinos.router, prefix="/api/v1")

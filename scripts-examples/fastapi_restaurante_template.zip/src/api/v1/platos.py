from fastapi import APIRouter

router = APIRouter(prefix='/platos', tags=['platos'])

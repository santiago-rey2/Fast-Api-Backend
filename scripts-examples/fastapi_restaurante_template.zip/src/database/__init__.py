from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from src.core.config import settings

engine = create_engine(
    settings.sync_dsn, echo=settings.sql_echo,
    pool_pre_ping=True, pool_recycle=3600, future=True
)

class Base(DeclarativeBase): pass

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

def init_db() -> None:
    from src.entities import plato, vino, categoria, alergeno, uva  # noqa
    Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

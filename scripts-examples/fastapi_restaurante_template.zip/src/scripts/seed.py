def run():
    print('Seed inicial')

if __name__ == '__main__':
    run()
